The program has been compiled using :
 � Microsoft CL & CL64 compiler version 16.00.40219.01 and linker version 10.00.40219.01;
 � Microsoft Windows SDK v. 7.1 headers and libraries;
 � Microsoft Windows DDK v. 7600.16385.1 libraries;
 � Native-NT-Toolkit headers.

After setting the environment variables INCLUDE (mine is �C:\WINSDK\v7.1\Include;C:\WINSDK\ndk�) and LIB (mine is �C:\WINSDK\v7.1\Lib�), run :
 � �build_dwmapi.bat�;
 � �build64.bat�;
 � �build.bat�.

Please don't pay attention to the bad code; I am not a professional programmer and this is just a �proof of concept��