//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by script1.rc
//
#define IDR_DWMAPI32                    102
#define IDR_DWMAPI64                    103
#define IDR_DESKN                       105
#define IDD_MAINWIN                     106
#define IDI_ICON1                       107
#define IDR_IEMANIFEST                  109
#define IDR_DPI64                       110
#define IDC_INSTALL                     1000
#define IDC_UNINST                      1001
#define IDC_DESKN                       1002
#define IDC_PATCHIE                     1003
#define IDC_DONOW                       1004

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        111
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
