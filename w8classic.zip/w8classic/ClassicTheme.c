#include <windows.h>
#include <tlhelp32.h>
#include <shlwapi.h>
#include <shlobj.h>
#include <Sddl.h>

#define PROCESSNAME "WinLogon.exe"
//#define HANDLENAME L"\\Sessions\\%u\\Windows\\ThemeSection"
#define HANDLENAME L"\\ThemeSection"
#define PROGNAME "ClassicTheme"

//////////////////////////////////////////////////////////////

typedef int (__stdcall *NTQUERYSYSTEMINFORMATION)(int SystemInformationClass, void *SystemInformation, int SystemInformationLength, int *ReturnLength);
NTQUERYSYSTEMINFORMATION NtQuerySystemInformation = NULL;

typedef int (__stdcall *NTQUERYOBJECT)(HANDLE ObjectHandle, int ObjectInformationClass, void *ObjectInformation, int ObjectInformationLength, int *ReturnLength);
NTQUERYOBJECT NtQueryObject = NULL;


//////////////////////////////////////////////////////////////

typedef struct _SYSTEM_HANDLE_ENTRY {
  ULONG  OwnerPid;
  BYTE   ObjectType;
  BYTE   HandleFlags;
  USHORT HandleValue;
  PVOID  ObjectPointer;
  ULONG  AccessMask;
} SYSTEM_HANDLE_ENTRY, *PSYSTEM_HANDLE_ENTRY;

typedef struct _SYSTEM_HANDLE_INFORMATION {
  ULONG               Count;
  SYSTEM_HANDLE_ENTRY Handle[1];
} SYSTEM_HANDLE_INFORMATION, *PSYSTEM_HANDLE_INFORMATION;

typedef struct _UNICODE_STRING {
  USHORT  Length;
  USHORT  MaximumLength;
  PWSTR  Buffer;
} UNICODE_STRING, *PUNICODE_STRING;

typedef struct _OBJECT_NAME_INFORMATION {
  UNICODE_STRING Name;
} OBJECT_NAME_INFORMATION, *POBJECT_NAME_INFORMATION;


//////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////

int GetPID(char *name) {
  HANDLE hth=0; PROCESSENTRY32 pe; int ret=0;

  hth = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
  if(!hth) return 0;
  ZeroMemory(&pe, sizeof(pe));
  pe.dwSize = sizeof(pe);
  Process32First(hth, &pe);

  do {
    if(!lstrcmpi(pe.szExeFile, name)) ret = pe.th32ProcessID;
  } while(Process32Next(hth, &pe));

  return ret;
}

#define STATUS_INFO_LENGTH_MISMATCH 0xC0000004

//////////////////////////////////////////////////////////////

void MainService() {
  HANDLE hNtDll=0; HANDLE hProcess;
  UINT i, pid=0, ret; char tmp[256]; int bsize=0;
  SYSTEM_HANDLE_INFORMATION *pshi=NULL;
  char nameh[2048]; WORD *namehc; int namehl;
  HANDLE handle;

  hNtDll = LoadLibrary("ntdll.dll");
  NtQuerySystemInformation = (NTQUERYSYSTEMINFORMATION)GetProcAddress(hNtDll, "NtQuerySystemInformation");
  NtQueryObject = (NTQUERYOBJECT)GetProcAddress(hNtDll, "NtQueryObject");

  pid = GetPID(PROCESSNAME);
  if(!pid) {
    //MessageBox(NULL, "Processus non trouv�", "", 16); 
    goto ProcessNotFound;
  }
  
  // R�cup�re la liste globale des Handles
  ret = NtQuerySystemInformation(16, tmp, sizeof(SYSTEM_HANDLE_INFORMATION), &bsize);
  if(ret==STATUS_INFO_LENGTH_MISMATCH && bsize) {
    pshi = HeapAlloc(GetProcessHeap(), 0, bsize);
    if(!pshi) ExitProcess(1);
    ret = NtQuerySystemInformation(16, pshi, bsize, NULL);
  } 

  hProcess = OpenProcess(PROCESS_ALL_ACCESS, FALSE, pid);
  if(!hProcess) {
    wsprintf(tmp, "Impossible d'ouvrir le processus : %u", GetLastError());
    //MessageBox(NULL, tmp, "", 16);
    goto ProcessNotFound;
  }

  for(i=0; i<pshi->Count; i++) {
    if(pshi->Handle[i].OwnerPid == pid) {
      // Duplique le handle pour pouvoir obtenir son nom
      DuplicateHandle(hProcess, (HANDLE)pshi->Handle[i].HandleValue, GetCurrentProcess(), &handle, 0, FALSE, DUPLICATE_SAME_ACCESS);
      // Demande le nom du handle
      NtQueryObject(handle, 1, &nameh, sizeof(nameh), NULL);
      namehl = ((UNICODE_STRING*)nameh)->Length;
      if(!namehl) goto cont;
      namehc = ((UNICODE_STRING*)nameh)->Buffer;
      if(namehl) *(WORD*)(namehc+namehl) = 0;

      if(StrStrIW(namehc, HANDLENAME)) {
	// D�truit le handle
	DuplicateHandle(hProcess, (HANDLE)pshi->Handle[i].HandleValue, GetCurrentProcess(), NULL, 0, FALSE, DUPLICATE_CLOSE_SOURCE);
	CloseHandle(handle);
	break;
      }
cont:
      CloseHandle(handle);
    }
  }

  CloseHandle(hProcess);

ProcessNotFound:

  ExitProcess(0);
}

//////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////

void MainUserinit() {
  HKEY hKey=NULL;
  char ExplorerName[] = "explorer.exe";
  char Path[256];
  SC_HANDLE sc_Handle = NULL, drv_Handle;

  ///////

  sc_Handle = OpenSCManager(NULL, SERVICES_ACTIVE_DATABASE, SC_MANAGER_CONNECT);
  if(sc_Handle) {
    drv_Handle = OpenService(sc_Handle, PROGNAME, SERVICE_START | SERVICE_STOP | SERVICE_QUERY_STATUS | SERVICE_INTERROGATE);
    if(drv_Handle) {
      StartService(drv_Handle, 0, NULL);
      CloseServiceHandle(drv_Handle);
    }
    CloseServiceHandle(sc_Handle);
  }

  Sleep(500);

  ///////

  RegOpenKeyEx(HKEY_LOCAL_MACHINE, "Software\\Microsoft\\Windows NT\\CurrentVersion\\Winlogon", 0, KEY_SET_VALUE | KEY_WOW64_64KEY, &hKey);
  if(hKey) {
    RegSetValueEx(hKey, "Shell", 0, REG_SZ, ExplorerName, sizeof(ExplorerName));
  }
    
  ShellExecute(0, "open", "userinit.exe", NULL, NULL, SW_SHOWDEFAULT);

  if(hKey) {
    Sleep(5000);
    GetModuleFileName(GetModuleHandle(NULL), Path, sizeof(Path));
    RegSetValueEx(hKey, "Shell", 0, REG_SZ, Path, strlen(Path));
    RegCloseKey(hKey);
  }

  ExitProcess(0);
}

//////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////

char *GetTrustedSID() {
  PSID Sid=NULL; int SidSize=0, tmp=0;
  SID_NAME_USE peUse=0;
  char *str=NULL;

  LookupAccountName(NULL, "NT SERVICE\\TrustedInstaller", NULL, &SidSize, NULL, &tmp, &peUse);
  Sid = HeapAlloc(GetProcessHeap(), 0, SidSize);
  str = HeapAlloc(GetProcessHeap(), 0, tmp);
  LookupAccountName(NULL, "NT SERVICE\\TrustedInstaller", Sid, &SidSize, str, &tmp, &peUse);
  HeapFree(GetProcessHeap(), 0, str);
  ConvertSidToStringSid(Sid, &str);
  HeapFree(GetProcessHeap(), 0, Sid);
  return str;
}

void Install() {
  char Path[512]; HKEY hKey=NULL;
  SC_HANDLE sc_Handle = NULL, drv_Handle;
  SECURITY_DESCRIPTOR *psd; char satext[1024];

  sc_Handle = OpenSCManager(NULL, SERVICES_ACTIVE_DATABASE, SC_MANAGER_CREATE_SERVICE);

  GetModuleFileName(GetModuleHandle(NULL), Path, sizeof(Path));

  if(sc_Handle) {
    drv_Handle = CreateService(sc_Handle, PROGNAME, PROGNAME, SERVICE_ALL_ACCESS, \
      SERVICE_WIN32_OWN_PROCESS, SERVICE_DEMAND_START, SERVICE_ERROR_IGNORE, Path, NULL, NULL,  NULL, NULL, NULL);

    if(!drv_Handle) {
      MessageBox(NULL, "Unable to create the service.", PROGNAME, 16);
      ExitProcess(1);
    }

    strcpy(satext, "D:(A;;GA;;;CO)(A;;GA;;;BA)(A;;CCLCRPWPLO;;;AU)");
    ConvertStringSecurityDescriptorToSecurityDescriptor(satext, 1, &psd, NULL);
    SetServiceObjectSecurity(drv_Handle, DACL_SECURITY_INFORMATION, psd);

    CloseServiceHandle(drv_Handle);
    CloseServiceHandle(sc_Handle);
  }

  //

  RegOpenKeyEx(HKEY_LOCAL_MACHINE, "Software\\Microsoft\\Windows NT\\CurrentVersion\\Winlogon", 0, KEY_ALL_ACCESS | KEY_WOW64_64KEY, &hKey);

  wsprintf(satext, "D:ARAI(A;;GA;;;SY)(A;;GA;;;BA)(A;;GA;;;%s)(A;;GA;;;BU)", GetTrustedSID());
  ConvertStringSecurityDescriptorToSecurityDescriptor(satext, 1, &psd, NULL);
  RegSetKeySecurity(hKey, DACL_SECURITY_INFORMATION, psd);

  GetModuleFileName(GetModuleHandle(NULL), Path, sizeof(Path));
  RegSetValueEx(hKey, "Shell", 0, REG_SZ, Path, strlen(Path));

  if(hKey) {
    MessageBox(NULL, "Program successfully installed. Please log off and on again.", PROGNAME, 64);
  }
}

void Uninstall() {
  char Path[512]; HKEY hKey;
  SC_HANDLE sc_Handle = NULL, drv_Handle;
  char ExplorerName[] = "explorer.exe";
  SECURITY_DESCRIPTOR *psd; char satext[1024];

  sc_Handle = OpenSCManager(NULL, SERVICES_ACTIVE_DATABASE, SC_MANAGER_CREATE_SERVICE);

  GetModuleFileName(GetModuleHandle(NULL), Path, sizeof(Path));

  drv_Handle = OpenService(sc_Handle, PROGNAME, SERVICE_ALL_ACCESS);
  DeleteService(drv_Handle);

  CloseServiceHandle(drv_Handle);
  CloseServiceHandle(sc_Handle);

  //

  RegOpenKeyEx(HKEY_LOCAL_MACHINE, "Software\\Microsoft\\Windows NT\\CurrentVersion\\Winlogon", 0, KEY_SET_VALUE | KEY_WOW64_64KEY, &hKey);
  RegSetValueEx(hKey, "Shell", 0, REG_SZ, ExplorerName, sizeof(ExplorerName));

  wsprintf(satext, "D:ARAI(A;;GA;;;SY)(A;;GA;;;BA)(A;;GA;;;%s)(A;;GR;;;BU)", GetTrustedSID());
  ConvertStringSecurityDescriptorToSecurityDescriptor(satext, 1, &psd, NULL);
  RegSetKeySecurity(hKey, DACL_SECURITY_INFORMATION, psd);

  if(hKey) {
    MessageBox(NULL, "Program successfully uninstalled. Please log off and on again.", PROGNAME, 64);
  }
}

//////////////////////////////////////////////////////////////

void MainNormal() {
  SC_HANDLE sc_Handle = NULL, drv_Handle;
  int ret;
  OSVERSIONINFO osvi;
  char Path[1024];

  ZeroMemory(&osvi, sizeof(osvi)); osvi.dwOSVersionInfoSize=sizeof(osvi);
  GetVersionEx(&osvi);

  if(osvi.dwMajorVersion<6 || osvi.dwMinorVersion<2) {
    MessageBox(NULL, "This program is meant to be run under Windows 8 or 8.1.", PROGNAME, 48);
    ExitProcess(0);
  }

  ret = IsUserAnAdmin();
  if(!ret) {
    GetModuleFileName(GetModuleHandle(NULL), Path, sizeof(Path));
    ShellExecute(NULL, "runas", Path, NULL, NULL, SW_SHOWNORMAL);
    ExitProcess(0);
  }

  sc_Handle = OpenSCManager(NULL, SERVICES_ACTIVE_DATABASE, SC_MANAGER_CONNECT);
  drv_Handle = OpenService(sc_Handle, PROGNAME, SERVICE_START | SERVICE_STOP | SERVICE_QUERY_STATUS | SERVICE_INTERROGATE);

  if(drv_Handle) {
    CloseServiceHandle(drv_Handle);
    CloseServiceHandle(sc_Handle);
    ret = MessageBox(NULL, "Do you want to uninstall this program?", PROGNAME, 32 | MB_YESNO);
    if(ret==IDYES) Uninstall();
  }
  else {
    CloseServiceHandle(sc_Handle);
    ret = MessageBox(NULL, "Do you want to install this program?\nWARNING: If the program does not work correctly, your computer may not start up anymore!", PROGNAME, 32 | MB_YESNO);
    if(ret==IDYES) Install();
  }

  ExitProcess(0);
}

//////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////

void WinMainCRTStartup() {
  HANDLE hTH; PROCESSENTRY32 pe; UINT pid, parpid;

  pid = GetCurrentProcessId();

  hTH = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
  
  pe.dwSize = sizeof(pe);
  Process32First(hTH, &pe);
  do {
    if(pe.th32ProcessID==pid) {
      parpid = pe.th32ParentProcessID;
      break;
    }
  } while(Process32Next(hTH, &pe));

  pe.dwSize = sizeof(pe);
  Process32First(hTH, &pe);
  do {
    if(pe.th32ProcessID==parpid) {
      if(!lstrcmpi(pe.szExeFile, "services.exe")) MainService();
      if(!lstrcmpi(pe.szExeFile, "userinit.exe")) MainUserinit();
    }
  } while(Process32Next(hTH, &pe));

  MainNormal();

  ExitProcess(0);
}
